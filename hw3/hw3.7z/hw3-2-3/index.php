<!doctype html>
<html lang="ru">
<head>
  <title>HW3-2-3</title>
  <meta charset="UTF-8">
  <meta name="viewport"
        content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
	<link rel="stylesheet" href="style.css">
	
</head>
<body>
<?php

;?>

<div class="container">
	<form id="solution" action="action.php" method="post">
		<h3>ДЗ 3 - задание 2-3</h3>
		<h4>
      Сделать программу, выводящую факториал числа (произведение чисел от 1 одного до n), где n любое число больше 1.
    </h4>
		<hr>
    <h4>Выберите число</h4>
    <fieldset>
      <input name="num" placeholder="любое число больше 1" type="number" tabindex="1" autofocus>
    </fieldset>


    <fieldset>
			<button name="submit" type="submit" id="contact-submit" data-submit="...Sending">Посчитать</button>
		</fieldset>
	</form>


</div>
</body>
</html>