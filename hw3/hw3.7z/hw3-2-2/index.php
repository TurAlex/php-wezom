<!doctype html>
<html lang="ru">
<head>
  <title>HW3-2-2</title>
  <meta charset="UTF-8">
  <meta name="viewport"
        content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
	<link rel="stylesheet" href="style.css">
	
</head>
<body>
<?php

;?>

<div class="container">
	<form id="solution" action="action.php" method="post">
		<h3>ДЗ 3 - задание 2-2</h3>
		<h4>
      С помощью цикла while() напишите скрипт вывода всех четных чисел в диапазоне от 2 до 100 включительно.
    </h4>
		<hr>
    <h4>Выберите диапазон чисел</h4>
    <fieldset>
      <input name="min" value="2" type="number" tabindex="1" autofocus>
    </fieldset>
    <fieldset>
      <input name="max" value="100" type="number" tabindex="2">
    </fieldset>


    <fieldset>
			<button name="submit" type="submit" id="contact-submit" data-submit="...Sending">Показать</button>
		</fieldset>
	</form>


</div>
</body>
</html>